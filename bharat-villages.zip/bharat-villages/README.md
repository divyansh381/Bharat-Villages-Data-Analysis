# 🇮🇳 Bharat Villages — Census 2011 Directory

A full-stack web app to explore **86,166 villages and towns** from India's 2011 Census.

## Requirements

- **Node.js v22+** (uses built-in `node:sqlite`)

## Quick Start

```bash
./start.sh
```

Then open **http://localhost:3000** in your browser.

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/stats` | Summary stats for all states |
| GET | `/api/states` | List of all states |
| GET | `/api/districts?state=GOA` | Districts for a state |
| GET | `/api/subdistricts?state=GOA&district=North+Goa` | Sub-districts |
| GET | `/api/places?state=GOA&district=...&subdistrict=...&q=...&page=1&limit=100` | Places with pagination |
| GET | `/api/search?q=patan` | Full-text search across all places |
| GET | `/api/place/:id` | Single place detail + neighbours |

## Dataset

- **Source**: Census of India 2011 — MDDS Place Name Codes
- **11 States**: Punjab, Haryana, Sikkim, Nagaland, Mizoram, Meghalaya, Chhattisgarh, Gujarat, Goa, Kerala, Tamil Nadu
- **Hierarchy**: State → District → Sub-District → Place
- **Database**: SQLite (`backend/villages.db`) — 16 MB
