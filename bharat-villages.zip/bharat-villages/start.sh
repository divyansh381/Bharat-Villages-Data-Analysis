#!/bin/bash
# ─── Bharat Villages — Start Script ───────────────────────
echo ""
echo "  🇮🇳  Bharat Villages — Census 2011 Directory"
echo "  ─────────────────────────────────────────────"

# Kill anything on port 3000
fuser -k 3000/tcp 2>/dev/null

# Start server
node "$(dirname "$0")/backend/server.js"
