/**
 * Bharat Villages API — Pure Node.js backend
 * Uses only built-in modules: http, fs, path, url
 * Uses Node 22 built-in SQLite (node:sqlite)
 */

'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');
const { DatabaseSync } = require('node:sqlite');

// ── Config ──────────────────────────────────────────────
const PORT = 3000;
const DB_PATH = path.join(__dirname, 'villages.db');
const STATIC_DIR = path.join(__dirname, '../frontend/public');

// ── DB ───────────────────────────────────────────────────
const db = new DatabaseSync(DB_PATH, { open: true });

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript',
  '.css':  'text/css',
  '.json': 'application/json',
  '.ico':  'image/x-icon',
  '.png':  'image/png',
  '.svg':  'image/svg+xml',
};

// ── API Handlers ─────────────────────────────────────────

function apiStats(req, res) {
  const rows = db.prepare(`
    SELECT state, COUNT(*) as total,
           COUNT(DISTINCT district) as districts,
           COUNT(DISTINCT subdistrict) as subdistricts
    FROM places GROUP BY state ORDER BY state
  `).all();
  return json(res, { states: rows });
}

function apiStates(req, res) {
  const rows = db.prepare('SELECT DISTINCT state, state_code FROM places ORDER BY state').all();
  return json(res, { states: rows });
}

function apiDistricts(req, res, params) {
  const state = params.get('state');
  if (!state) return error(res, 400, 'state param required');
  const rows = db.prepare(
    'SELECT DISTINCT district, district_code FROM places WHERE state=? ORDER BY district'
  ).all(state);
  return json(res, { districts: rows });
}

function apiSubdistricts(req, res, params) {
  const state = params.get('state');
  const district = params.get('district');
  if (!state || !district) return error(res, 400, 'state and district params required');
  const rows = db.prepare(
    'SELECT DISTINCT subdistrict, subdistrict_code FROM places WHERE state=? AND district=? ORDER BY subdistrict'
  ).all(state, district);
  return json(res, { subdistricts: rows });
}

function apiPlaces(req, res, params) {
  const state = params.get('state') || '';
  const district = params.get('district') || '';
  const subdistrict = params.get('subdistrict') || '';
  const q = params.get('q') || '';
  const page = Math.max(1, parseInt(params.get('page') || '1'));
  const limit = Math.min(200, Math.max(1, parseInt(params.get('limit') || '100')));
  const offset = (page - 1) * limit;

  let where = [];
  let args = [];

  if (state)       { where.push('state=?');        args.push(state); }
  if (district)    { where.push('district=?');      args.push(district); }
  if (subdistrict) { where.push('subdistrict=?');   args.push(subdistrict); }
  if (q)           { where.push('place_name LIKE ?'); args.push(`%${q}%`); }

  const whereSQL = where.length ? 'WHERE ' + where.join(' AND ') : '';

  const total = db.prepare(`SELECT COUNT(*) as n FROM places ${whereSQL}`).get(...args).n;
  const rows  = db.prepare(`SELECT id,place_name,place_code,subdistrict,district,state FROM places ${whereSQL} ORDER BY place_name LIMIT ? OFFSET ?`).all(...args, limit, offset);

  return json(res, {
    total, page, limit,
    pages: Math.ceil(total / limit),
    places: rows,
  });
}

function apiSearch(req, res, params) {
  const q = params.get('q') || '';
  if (q.length < 2) return json(res, { results: [], total: 0 });

  const rows = db.prepare(`
    SELECT id,place_name,place_code,subdistrict,district,state
    FROM places WHERE place_name LIKE ? OR district LIKE ? OR subdistrict LIKE ?
    ORDER BY
      CASE WHEN place_name LIKE ? THEN 0
           WHEN place_name LIKE ? THEN 1
           ELSE 2 END,
      place_name
    LIMIT 200
  `).all(`%${q}%`, `%${q}%`, `%${q}%`, `${q}%`, `%${q}%`);

  return json(res, { results: rows, total: rows.length });
}

function apiPlace(req, res, id) {
  const row = db.prepare('SELECT * FROM places WHERE id=?').get(parseInt(id));
  if (!row) return error(res, 404, 'Place not found');
  // Also get neighbours in same subdistrict
  const neighbours = db.prepare(
    'SELECT id,place_name FROM places WHERE subdistrict=? AND state=? AND id!=? ORDER BY place_name LIMIT 20'
  ).all(row.subdistrict, row.state, row.id);
  return json(res, { place: row, neighbours });
}

// ── Helpers ──────────────────────────────────────────────

function json(res, data) {
  const body = JSON.stringify(data);
  res.writeHead(200, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Cache-Control': 'no-cache',
  });
  res.end(body);
}

function error(res, code, msg) {
  res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify({ error: msg }));
}

function serveStatic(req, res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const contentType = MIME[ext] || 'application/octet-stream';
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404); res.end('Not found');
      return;
    }
    res.writeHead(200, { 'Content-Type': contentType });
    res.end(data);
  });
}

// ── Router ───────────────────────────────────────────────
const server = http.createServer((req, res) => {
  const base = `http://${req.headers.host || 'localhost'}`;
  const url = new URL(req.url, base);
  const pathname = url.pathname;
  const params = url.searchParams;

  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET', 'Access-Control-Allow-Headers': 'Content-Type' });
    return res.end();
  }

  // API routes
  if (pathname === '/api/stats')        return apiStats(req, res);
  if (pathname === '/api/states')       return apiStates(req, res);
  if (pathname === '/api/districts')    return apiDistricts(req, res, params);
  if (pathname === '/api/subdistricts') return apiSubdistricts(req, res, params);
  if (pathname === '/api/places')       return apiPlaces(req, res, params);
  if (pathname === '/api/search')       return apiSearch(req, res, params);

  const placeMatch = pathname.match(/^\/api\/place\/(\d+)$/);
  if (placeMatch) return apiPlace(req, res, placeMatch[1]);

  // Static files
  let filePath = path.join(STATIC_DIR, pathname === '/' ? 'index.html' : pathname);
  // Sanitize: prevent directory traversal
  if (!filePath.startsWith(STATIC_DIR)) {
    res.writeHead(403); res.end('Forbidden');
    return;
  }
  serveStatic(req, res, filePath);
});

server.listen(PORT, () => {
  console.log(`✅  Bharat Villages API running at http://localhost:${PORT}`);
  console.log(`📊  Database: ${DB_PATH}`);
  console.log(`🌐  Frontend: ${STATIC_DIR}`);
});
